package sch.bot.SchDemoBot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SchDemoBotApplication {

	public static void main(String[] args) {
		SpringApplication.run(SchDemoBotApplication.class, args);
	}
}

